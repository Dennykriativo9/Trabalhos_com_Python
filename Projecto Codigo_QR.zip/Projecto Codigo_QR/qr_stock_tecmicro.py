# Algoritmo para resolver o problema de Logistica com QR code  # prototipo do real 

import segno


produto = input(" Digite o nome do Produto: ")
id = input(" Digite o ID do Produto: ")
tecnico = input(" Digite o nome do Tecnico em Serviço: ")

texto =f" TECMICRO ANGOLA \n  PRODUTO : {produto} \n ID : {id} \n TECNICO : {tecnico}"




qrcode = segno.make_qr(texto)
qrcode.save(f"{produto}.png",scale = 10)


